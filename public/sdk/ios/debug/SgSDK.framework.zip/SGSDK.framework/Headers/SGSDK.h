//
//  SGSDK.h
//  SGSDK
//
//  Created by 張又壬 on 2017/4/18.
//  Copyright © 2017年 SmartGames Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>

//! Project version number for SGSDK.
FOUNDATION_EXPORT double SGSDKVersionNumber;

//! Project version string for SGSDK.
FOUNDATION_EXPORT const unsigned char SGSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SGSDK/PublicHeader.h>

#import "WXApi.h"
#import "WXApiObject.h"
#import "WechatAuthSDK.h"
