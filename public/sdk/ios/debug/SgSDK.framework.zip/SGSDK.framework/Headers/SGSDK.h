//
//  SGSDK.h
//  SGSDK
//
//  Created by 張又壬 on 2017/4/18.
//  Copyright © 2017年 smartgamesltd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SGSDK.
FOUNDATION_EXPORT double SGSDKVersionNumber;

//! Project version string for SGSDK.
FOUNDATION_EXPORT const unsigned char SGSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SGSDK/PublicHeader.h>


