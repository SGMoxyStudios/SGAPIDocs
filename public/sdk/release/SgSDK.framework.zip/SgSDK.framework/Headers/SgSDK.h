//
//  SgSDK.h
//  SgSDK
//
//  Created by 張又壬 on 2017/3/24.
//  Copyright © 2017年 SmartGames. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SgSDK.
FOUNDATION_EXPORT double SgSDKVersionNumber;

//! Project version string for SgSDK.
FOUNDATION_EXPORT const unsigned char SgSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SgSDK/PublicHeader.h>


